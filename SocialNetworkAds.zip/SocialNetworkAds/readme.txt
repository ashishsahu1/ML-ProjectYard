This is a Classficiation model using Social network Ads. Based on the person's gender, salary and age it will predict that whether the person will buy  the product or not.
It has a wide use in marketing.

The dataset used is -'Social_network_Ads.csv' 
It is deployed in a web app using django.

To run this project directly clone it- Open terminal - And run it by the command- 'python manage.py runserver'